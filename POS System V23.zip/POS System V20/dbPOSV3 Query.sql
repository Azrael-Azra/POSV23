CREATE DATABASE dbPOSV3

USE master


CREATE TABLE tblAccounts(
    ID INT PRIMARY KEY IDENTITY,
    [STATUS] VARCHAR(50),
    ROLE VARCHAR(50),
    PASSWORD VARCHAR(255),
    EMPLOYEEID AS RIGHT('00000'  + CAST (ID  AS VARCHAR(5)),5)
)

CREATE TABLE tblEmployeeDetails (
    ID INT FOREIGN KEY(ID) REFERENCES tblAccounts,
    FIRST_NAME VARCHAR(50),
    LAST_NAME VARCHAR(50),
    MIDDLE_NAME VARCHAR(50),
    SEX VARCHAR(10),
    AGE INT,
    PHONENUMBER VARCHAR(15),
    BIRTHDAY DATE
);

CREATE TABLE tblProducts(
  Product_ID INT PRIMARY KEY IDENTITY,
    Product_Name VARCHAR(100),
    Price DECIMAL(10, 2),
    [Description] TEXT,
    [Image] VARCHAR(255),
    Category VARCHAR(50)
)

CREATE TABLE tblInventory(
    Product_ID INT FOREIGN KEY (Product_ID) REFERENCES tblProducts(Product_ID),
	Quantity INT
)

CREATE TABLE tblInventoryReports(
	StockNumber INT PRIMARY KEY IDENTITY,
    Product_ID INT FOREIGN KEY (Product_ID) REFERENCES tblProducts(Product_ID),
    ID INT FOREIGN KEY (ID) REFERENCES tblAccounts(ID),
    Quantity INT,
    Category VARCHAR(50),
    [DATE] DATE
)

CREATE TABLE tblTransaction(
	Transaction_ID INT PRIMARY KEY IDENTITY,
    ID INT FOREIGN KEY (ID) REFERENCES tblAccounts(ID),
    DATE DATE,
    Total DECIMAL(10, 2),
    AmountTendered DECIMAL(10, 2),
    Changed DECIMAL(10, 2)
)

CREATE TABLE tblTransaction(
	Transaction_ID INT PRIMARY KEY IDENTITY,
    ID INT FOREIGN KEY (ID) REFERENCES tblAccounts(ID),
    DATE DATE,
    Total DECIMAL(10, 2),
    AmountTendered DECIMAL(10, 2),
    Changed DECIMAL(10, 2)
)

CREATE TABLE tblTransactionDetails(
	Transaction_ID INT FOREIGN KEY (Transaction_ID) REFERENCES tblTransaction(Transaction_ID),
    Product_ID INT FOREIGN KEY (Product_ID) REFERENCES tblProducts(Product_ID),
    Quantity INT,
    SubTotal DECIMAL(10, 2)
    
)

SELECT * FROM tblAccounts