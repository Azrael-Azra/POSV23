﻿using ComponentFactory.Krypton.Toolkit;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_System
{
    public partial class ProductMngmntChild : Form
    {
        //var dec or init
        databasePOS db;
        int userId;
        string Cat = "All";
        public ProductMngmntChild()
        {
            InitializeComponent();
            pnlInventoryItem.Hide();
            cmbSelection.SelectedIndex = 0;
            cmb_category.SelectedIndex = 0;
        }

        //Clear user inputs in add inventory
        private void clearFields()
        {
            pbAddItem.Image = null;
            txtItemName.Clear();
            txtPrice.Clear();
            //numPadStock.Value = 0;
        }

        //populate flowlayout panel
        private void LoadAllItem(string category)
        {
            db = new databasePOS();
            flowpnlBg.Controls.Clear();

            // Fetch products based on the category
            var products = db.tblProducts.AsQueryable();

            if (category != "All")
            {
                products = products.Where(u => u.Category == category);
            }

            foreach (var data in products)
            {
                // Create a new panel
                Panel newPanel = new Panel
                {
                    Width = 270, // Adjust as needed
                    Height = 200, // Adjust as needed
                    BackColor = Color.White,
                    Padding = new Padding(10)
                };

                // Add a PictureBox for the image
                PictureBox pictureBox = new PictureBox
                {
                    Size = new Size(100, 100),
                    SizeMode = PictureBoxSizeMode.StretchImage,
                    Location = new Point(25, 35),
                    Margin = new Padding(100, 0, 100, 0)
                };

                if (data.Image != null)
                {
                    using (MemoryStream ms = new MemoryStream(data.Image.ToArray()))
                    {
                        pictureBox.Image = Image.FromStream(ms);
                    }
                }
                else
                {
                    pictureBox.Image = Properties.Resources.NA;
                }

                // Add a Label for the product name
                Label productLabel = new Label
                {
                    Text = data.Product_Name,
                    Font = new Font("Inter", 11, FontStyle.Bold),
                    ForeColor = Color.FromArgb(34, 34, 34),
                    Location = new Point(20, 10),
                    AutoSize = true,
                };

                var quantity = db.tblInventories.FirstOrDefault(u => u.Product_ID == data.Product_ID);

                // Add a Label for stock quantity
                Label stockLabel = new Label
                {
                    Text = $"Stock Qty: {quantity.Quantity}",
                    Font = new Font("Inter", 8),
                    ForeColor = Color.FromArgb(34, 34, 34),
                    Location = new Point(150, 60),
                    AutoSize = true
                };

                // Add a Label for the price
                Label priceLabel = new Label
                {
                    Text = $"Price: P{data.Price:0.00}",
                    ForeColor = Color.FromArgb(34, 34, 34),
                    Font = new Font("Inter", 8),
                    Location = new Point(150, 80),
                    AutoSize = true
                };

                // Add an Edit button
                Button editButton = new Button
                {
                    Text = "Edit",
                    Font = new Font("Inter", 8),
                    BackColor = Color.Goldenrod,
                    Location = new Point(150, 105),
                    Width = 100,
                    Height = 30,
                    FlatStyle = FlatStyle.Flat,
                    FlatAppearance = { BorderSize = 0 },
                    Tag = data
                };
                editButton.Click += EditButton_Click;

                TextBox descriptionTextBox = new TextBox
                {
                    Text = data.Description,
                    Font = new Font("Inter", 7),
                    ForeColor = Color.Gray,
                    BackColor = Color.White, // Matches the panel's background
                    BorderStyle = BorderStyle.None, // Optional: make it look like a label
                    Multiline = true,
                    ReadOnly = true, // Prevent user edits
                    Width = newPanel.Width - 20, // Adjust width to fit within panel's padding
                    Height = 30, // Adjust height as needed
                    Location = new Point(10, editButton.Bottom + 10), // Position below the edit button
                    TextAlign = HorizontalAlignment.Center // Center the text horizontally
                };

                // Add the TextBox to the panel
                newPanel.Controls.Add(descriptionTextBox);

                // Add the panel to the FlowLayoutPanel
                flowpnlBg.Controls.Add(newPanel);

                // Add all controls to the panel
                newPanel.Controls.Add(pictureBox);
                newPanel.Controls.Add(productLabel);
                productLabel.Left = (newPanel.Width - productLabel.Width) / 2;
                newPanel.Controls.Add(stockLabel);
                newPanel.Controls.Add(priceLabel);
                newPanel.Controls.Add(editButton);


            }
        }

        //show edit inventory
        private void EditButton_Click(object sender, EventArgs e)
        {
            pnlInventoryItem.Show();
            btnSave.Hide();
            btnEditSave.Show();

            Button editButon = sender as Button;

            if (editButon != null && editButon.Tag is tblProduct selectedItem)
            {
                if (selectedItem.Image != null)
                {
                    using (MemoryStream ms = new MemoryStream(selectedItem.Image.ToArray()))
                    {
                        pbAddItem.Image = Image.FromStream(ms);
                    }
                }
                else
                {
                    pbAddItem.Image = null;
                }

                //Populate the fields
                txtItemName.Text = selectedItem.Product_Name;
                txtPrice.Text = selectedItem.Price.ToString();
                //numPadStock.Value = (int)selectedItem.aoQty;

                userId = selectedItem.Product_ID;
            }
        }

        //hides inventory panel
        private void btnHide_Click_1(object sender, EventArgs e)
        {
            pbAddItem.Image = null;
            rtb_description.Text = "";
            pnlInventoryItem.Hide();
        }

        //show inventory panel
        private void button1_Click_1(object sender, EventArgs e)
        {
            pnlInventoryItem.Show();
            btnSave.Show();
            btnEditSave.Hide();
            clearFields();
        }

        //updates details
        private void btnEditSave_Click(object sender, EventArgs e)
        {
            //Validating Inputs
            string error = String.Empty;
            if (string.IsNullOrWhiteSpace(txtItemName.Text) || string.IsNullOrWhiteSpace(txtPrice.Text))
            {
                error += "Fields must not be empty\n";
            }

            if (!decimal.TryParse(txtPrice.Text, out decimal price))
            {
                error += "Enter valid price\n";
            }

            if (price == 0)
            {

            }

            db = new databasePOS();
            var item = db.tblProducts.FirstOrDefault(u => u.Product_ID == userId);
            
            //Validation if the item already exist on the database
            if (txtItemName.Text.ToUpper().Trim() != item.Product_Name)
            {
                var records = db.tblProducts.Where(u => u.Product_ID != userId).ToList();
                var check = records.FirstOrDefault(u => u.Product_Name == txtItemName.Text.ToUpper().Trim());
                if (check != null)
                {
                    if (check.Product_Name == txtItemName.Text.ToUpper().Trim())
                    {
                        error += "Item name already existed!";
                    }
                }
                
            }
            

            if (error == String.Empty)
            {
                //Confirmation  for update  changes
                DialogResult result = MessageBox.Show("Commit changes?", "Warning", MessageBoxButtons.OKCancel);

                if (result == DialogResult.OK)
                {
                    if (pbAddItem.Image != null)
                    {
                        byte[] imageData = ImageToByteArray(pbAddItem.Image);
                        db.updateProduct(userId, txtItemName.Text.ToUpper().Trim(), decimal.Parse(txtPrice.Text), imageData, rtb_description.Text, cmb_category.Text);
                    }
                    else
                    {
                        db.updateProduct(userId, txtItemName.Text.ToUpper().Trim(), decimal.Parse(txtPrice.Text), null, rtb_description.Text, cmb_category.Text);
                    }
                    pnlInventoryItem.Hide();
                    flowpnlBg.Controls.Clear();
                    LoadAllItem(cmb_category.Text);
                    cmbSelection.Text = cmb_category.Text;
                    MessageBox.Show("Success!");
                }
            }
            else
            {
                MessageBox.Show(error);
                error = String.Empty;
            }
        }


        //add inventory details to sql
        private void btnSave_Click(object sender, EventArgs e)
        {
            //Instantiate the database
            db = new databasePOS();

            //Validating Inputs
            string error = String.Empty;
            if (string.IsNullOrWhiteSpace(txtItemName.Text))
            {
                error += "Product Name must not be empty\n";
            }

            
            //Restrictions for invalid price
            if (!decimal.TryParse(txtPrice.Text, out decimal price))
            {
                if (string.IsNullOrWhiteSpace(txtPrice.Text) || int.Parse(price.ToString()) == 0)
                {
                    error += "Enter valid price\n";
                }
            }

            //Add errors if name already exist
            var check = db.tblProducts.Any(u => u.Product_Name == txtItemName.Text.ToUpper().Trim());
            if (check)
            {
                error += "Item name already exist! Please select other name";
            }
            if (error == String.Empty)
            {
                //Add products to sql
                if (pbAddItem.Image != null && pbAddItem.Tag != null)
                {
                    //add product if image is attached
                    byte[] imageData = ImageToByteArray(pbAddItem.Image);
                    db.addProduct(cmb_category.Text,txtItemName.Text.ToUpper().Trim(), decimal.Parse(txtPrice.Text), imageData, rtb_description.Text);
                }
                else
                {
                    db.addProduct(cmb_category.Text, txtItemName.Text.ToUpper().Trim(), decimal.Parse(txtPrice.Text), null, rtb_description.Text);
                }
                pnlInventoryItem.Hide();
                LoadAllItem(cmb_category.Text);
                cmbSelection.Text = cmb_category.Text;
                rtb_description.Text = "";
                MessageBox.Show("Success!");
            }
            else
            {
                MessageBox.Show(error,"Error");
                error = String.Empty;
            }
        }

        //Convert Image to byteArray
        private byte[] ImageToByteArray(Image imageIn)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Png); // Save in PNG format or any other format
                return ms.ToArray(); // Convert MemoryStream to byte array
            }
        }

        //upload image from pc
        #region UPLOAD IMAGE FROM PC
        private void btnUpload_Click(object sender, EventArgs e)
        {
            //Opening File explorer for picking an image
            using (OpenFileDialog open = new OpenFileDialog())
            {
                //Image file Filter
                open.Filter = "Image Files|*.jpg; *.jpeg; *.png; *.bmp;";
                if (open.ShowDialog() == DialogResult.OK)
                {
                    //Load image to pictureBox
                    pbAddItem.Image = Image.FromFile(open.FileName);
                    pbAddItem.Tag = open.FileName;
                }
            }
        }
        #endregion

        //price restriction
        private void txtPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            // Allow digits, one dot, and backspace
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true; // Ignore invalid characters
                return;
            }

            // Allow backspace to function
            if (e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false; // Do not block the backspace
                return;
            }

            // Check for one decimal point
            if (e.KeyChar == '.' && textBox.Text.Contains("."))
            {
                e.Handled = true; // Prevent multiple decimal points
                return;
            }

            // Split the current text into integer and decimal parts
            string[] parts = textBox.Text.Split('.');
            string integerPart = parts[0]; // The part before the decimal
            string decimalPart = parts.Length > 1 ? parts[1] : ""; // The part after the decimal

            // Check if integer part exceeds 7 digits
            if (integerPart.Length >= 7 && textBox.SelectionStart <= integerPart.Length && e.KeyChar != '.')
            {
                e.Handled = true; // Stop input if already 7 digits before the decimal
                return;
            }

            // Restrict decimal part to 2 digits
            if (textBox.Text.Contains(".") && decimalPart.Length >= 2 && textBox.SelectionStart > integerPart.Length)
            {
                e.Handled = true; // Stop input if 2 decimal places are reached
                return;
            }

            // Limit overall text length to 10 characters (7 digits + 1 dot + 2 decimal places)
            if (textBox.Text.Length >= 10 && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true; // Stop input if length exceeds 13
                return;
            }
        }

        //populate flowlayoutpanel during opening of form
        private void addonsForm_Load(object sender, EventArgs e)
        {
            LoadAllItem(Cat);
        }

        //searchbar restriction
        private void tb_search_TextChanged(object sender, EventArgs e)
        {
            db = new databasePOS();
            var search = db.tblProducts.Where(u => u.Product_Name.Contains(tb_search.Text.ToUpper().Trim())).ToList();

            if (string.IsNullOrWhiteSpace(tb_search.Text.Trim()))
            {
                cmbSelection.SelectedIndex = 0;
                lbl_displayError.Hide();
            }
            if (search.Count > 0)
            {
                flowpnlBg.Controls.Clear();
                lbl_displayError.Hide();

                foreach (var data in search)
                {
                    // Create a new panel
                    Panel newPanel = new Panel
                    {
                        Width = 270, // Adjust as needed
                        Height = 150, // Adjust as needed
                        BackColor = Color.White,
                        Padding = new Padding(10)
                    };

                    // Add a PictureBox for the image
                    PictureBox pictureBox = new PictureBox
                    {
                        Size = new Size(100, 100),
                        SizeMode = PictureBoxSizeMode.StretchImage,
                        Location = new Point(25, 35),
                        Margin = new Padding(100, 0, 100, 0)
                    };

                    if (data.Image != null)
                    {
                        using (MemoryStream ms = new MemoryStream(data.Image.ToArray()))
                        {
                            pictureBox.Image = Image.FromStream(ms);
                        }
                    }
                    else
                    {
                        pictureBox.Image = Properties.Resources.NA;
                    }

                    // Add a Label for the product name
                    Label productLabel = new Label
                    {
                        Text = data.Product_Name,
                        Font = new Font("Inter", 11, FontStyle.Bold),
                        ForeColor = Color.FromArgb(34, 34, 34),
                        Location = new Point(20, 10),
                        AutoSize = true,
                    };

                    // Add a Label for stock quantity
                    Label stockLabel = new Label
                    {
                        Text = $"Stock Qty: ",
                        Font = new Font("Inter", 8),
                        ForeColor = Color.FromArgb(34, 34, 34),
                        Location = new Point(150, 60),
                        AutoSize = true
                    };

                    // Add a Label for the price
                    Label priceLabel = new Label
                    {
                        Text = $"Price: P{data.Price:0.00}",
                        ForeColor = Color.FromArgb(34, 34, 34),
                        Font = new Font("Inter", 8),
                        Location = new Point(150, 80),
                        AutoSize = true
                    };

                    // Add an Edit button
                    Button editButton = new Button
                    {
                        Text = "Edit",
                        Font = new Font("Inter", 8),
                        BackColor = Color.Goldenrod,
                        Location = new Point(150, 105),
                        Width = 100,
                        Height = 30,
                        FlatStyle = FlatStyle.Flat,
                        FlatAppearance = { BorderSize = 0 },
                        Tag = data
                    };
                    editButton.Click += EditButton_Click;

                    // Add the panel to the FlowLayoutPanel
                    flowpnlBg.Controls.Add(newPanel);

                    // Add all controls to the panel
                    newPanel.Controls.Add(pictureBox);
                    newPanel.Controls.Add(productLabel);
                    productLabel.Left = (newPanel.Width - productLabel.Width) / 2;
                    newPanel.Controls.Add(stockLabel);
                    newPanel.Controls.Add(priceLabel);
                    newPanel.Controls.Add(editButton);
                }
            }
            else
            {
                flowpnlBg.Controls.Clear();

                if (!string.IsNullOrWhiteSpace(tb_search.Text.Trim()))
                {
                    lbl_displayError.Show();
                }
                
            }
        }

        //Filters the product by categories
        private void cmbSelection_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCategory = cmbSelection.SelectedItem.ToString();
            LoadAllItem(selectedCategory);
        }

        
    }
}
