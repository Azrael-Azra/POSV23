﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_System
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();

            //triggers login validation when enter is pressed
            tb_userID.KeyDown += accountValidation;
            tb_password.KeyDown += accountValidation;
        }

        #region KEYS 'ENTER' IS PRESSED
        //Proceed to login validation after pressing 'ENTER' key
        private void accountValidation(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                loginValidation(); //navigate to loginvalidation method
            }
        }
        #endregion

        //Validates user input

        #region VALIDATES ACCOUNT
        private void loginValidation()
        {
            //Calls the methods to the UserManager Class to validate
            if (UserManager.checkAccount(tb_userID.Text.ToUpper().Trim(), tb_password.Text.ToUpper().Trim()))
            {
                UserManager.checkInactiveAccount(tb_userID.Text.ToUpper().Trim(),this); //checks inactive
            }
            else
            {
                MessageBox.Show("Invalid Credentials"); //if account is invalid
            }

        }
        #endregion
        //clear textbox fields

        #region CLEAR LOGIN FIELDS
        public void ClearLoginFields()
        {
            tb_userID.Clear();
            tb_password.Clear();
            tb_userID.Focus();
        }
        #endregion
        //Account validation

        #region CALLS VALIDATION METHOD IF BUTTON IS CLICKED
        private void button1_Click(object sender, EventArgs e)
        {
            loginValidation();
        }
        #endregion
        //public method to show loginForm
        #region SHOW FORM
        public void showForm()
        {
            this.Show();
        }
        #endregion
        //checkbox restriction

        #region SHOW PASSWORD
        private void chk_show_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_show.Checked)
            {
                tb_password.PasswordChar = '\0';
            }
            else
            {
                tb_password.PasswordChar = '*';
            }
        }
        #endregion
        //Exits the application
        #region APPLICATION EXIT
        private void Login_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
        #endregion

    }
}
