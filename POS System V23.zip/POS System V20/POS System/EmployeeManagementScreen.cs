﻿using ComponentFactory.Krypton.Toolkit;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_System
{
    public partial class EmployeeManagementScreen : Form
    {
        //Variable declaration and instantiation
        databasePOS db = new databasePOS();
        int age;
        DateTime bday;
        DateTime today;
        int currentIndex;

        public EmployeeManagementScreen()
        {
            InitializeComponent();
            PopulateDataGrid();
            panelChildform.Hide();
            btnHide.Hide();
            lbl_employementID.Text = UserManager.userID;
        }

        //populate grid
        private void PopulateDataGrid()
        {
            dgvEmp.DataSource = db.showEmployee();

        }

        //save credentials
        private void button3_Click(object sender, EventArgs e)
        {
            var user = db.tblAccounts.FirstOrDefault(u => u.ID == currentIndex);
            var user2 = db.tblEmployeeDetails.FirstOrDefault(u => u.ID == currentIndex);
            bool proceed = true;

            //handles empty fields
            if (user != null)
            {
                foreach (Control x in this.Controls)
                {
                    if (x is KryptonTextBox && (string)x.Tag == "tb" && string.IsNullOrWhiteSpace(x.Text))
                    {
                        MessageBox.Show("Fields cannot be empty");
                        proceed = false;
                        break;
                    }
                    else
                    {
                        proceed = true;
                    }
                }

                if (string.IsNullOrWhiteSpace(cmb_sex.Text))
                {
                    proceed = false;
                    MessageBox.Show("Input valid sex");
                }
                if (proceed)
                {
                    if (age < 18)
                    {
                        MessageBox.Show("Age must be 18 or above");
                    }
                    else
                    {
                        DialogResult result = MessageBox.Show("Commit Changes?", "Warning", MessageBoxButtons.YesNo);

                        if (result == DialogResult.Yes)
                        {
                            long phone;
                            if (string.IsNullOrWhiteSpace(tb_phone.Text))
                            {
                                phone = 0;
                            }
                            else
                            {
                                phone = long.Parse(tb_phone.Text);
                            }
                            DateTime date = dtp_bday.Value.Date;
                            db.updateAll(currentIndex, cmb_status.Text, cmb_role.Text, tb_password.Text, tb_firstName.Text.ToUpper(), tb_lastName.Text.ToUpper(), tb_middleName.Text.ToUpper(), cmb_sex.Text, tb_age.Text, phone, Convert.ToDateTime(dtp_bday.Value.Date));
                            MessageBox.Show("Employee details successfuly updated");
                            PopulateDataGrid();
                        }
                    }
                }
            }
        }

        //configure datagridview clicking
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            db = new databasePOS();
            if (e.RowIndex >= 0)
            {
                currentIndex = int.Parse(dgvEmp.Rows[e.RowIndex].Cells[0].Value.ToString());

                var account = db.tblAccounts.FirstOrDefault(u => u.ID == currentIndex);
                var details = db.tblEmployeeDetails.FirstOrDefault(u => u.ID == currentIndex);

                if (account != null)
                {
                    lbl_employementID.Text = account.EMPLOYEEID.ToString();
                    tb_firstName.Text = details.FIRST_NAME;
                    tb_lastName.Text = details.LAST_NAME;
                    tb_middleName.Text = details.MIDDLE_NAME;
                    cmb_sex.Text = details.SEX;
                    tb_age.Text = details.AGE;
                    tb_phone.Text = details.PHONENUMBER.ToString();
                    if (details.BIRTHDAY != null)
                    {
                        dtp_bday.Value = Convert.ToDateTime(details.BIRTHDAY);
                    }

                    cmb_status.Text = account.STATUS;
                    cmb_role.Text = account.ROLE;
                    tb_password.Text = account.PASSWORD;
                }
            }
            else if (e.RowIndex == db.tblAccounts.Count())
            {
                MessageBox.Show("Please select valid row");
            }

        }

        
        //hide and show password
        private void chk_show_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_show.Checked)
            {
                tb_password.PasswordChar = '\0';
            }
            else
            {
                tb_password.PasswordChar = '*';
            }
        }

        //configure bdate
        private void dtp_bday_ValueChanged(object sender, EventArgs e)
        {
            DateTime bday = dtp_bday.Value;
            DateTime today = DateTime.Now;

            age = today.Year - bday.Year;

            if (bday > today.AddYears(-age))
            {
                age--;
            }

            tb_age.Text = age.ToString();
        }

        //configure keypress
        private void tb_phone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        //trigger textchange
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(tb_search.Text))
            {
                PopulateDataGrid();
            }
            else if (int.Parse(tb_search.Text) > db.tblAccounts.Count())
            {

            }
            else
            {
                var filter = db.tblAccounts.FirstOrDefault(u => u.ID == int.Parse(tb_search.Text));

                int index = int.Parse(tb_search.Text);

                dgvEmp.DataSource = db.showFiltered(index);
            }



        }

        //allow data search
        private void tb_search_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        //create parent and child forms
        private Form activeForm = null;
        private void OpenChildform(Form childform)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelChildform.Controls.Add(childform);
            panelChildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }

        //allow button clicking
        private void btnAddEmployee_Click(object sender, EventArgs e)
        {
            panelChildform.Visible = true;
            OpenChildform(new RegistrationScreen());
            panelChildform.Show();
            btnHide.Show();
        }

        //hide panel
        private void btnHide_Click_2(object sender, EventArgs e)
        {
            panelChildform.Hide();
            btnHide.Hide();
            PopulateDataGrid();
        }
    }
}
